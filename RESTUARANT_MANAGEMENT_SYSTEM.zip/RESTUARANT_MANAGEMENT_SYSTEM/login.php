<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login | Restaurant System</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #FFE6F2; 
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}
.container {
    background: #FFFFFF;
    width: 350px;
    padding: 20px;
    border-radius: 15px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}
h2 {
    text-align: center;
    color: #FF69B4;
}
input {
    width: 100%;
    padding: 10px;
    margin-bottom: 12px;
    border: 2px solid #FFB6C1;
    border-radius: 8px;
}
button {
    width: 100%;
    padding: 10px;
    background: #FF69B4;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}
button:hover {
    background: #FF1493;
}
</style>
</head>
<body>

<div class="container">
<h2>Login</h2>

<form method="POST" action="login_check.php">

<input type="email" name="email" placeholder="Enter Email" required>
<input type="password" name="password" placeholder="Enter Password" required>

<button type="submit">Login</button>

</form>
</div>

</body>
</html>
