<?php
<?php include 'db.php';
echo "this is index page";
?>