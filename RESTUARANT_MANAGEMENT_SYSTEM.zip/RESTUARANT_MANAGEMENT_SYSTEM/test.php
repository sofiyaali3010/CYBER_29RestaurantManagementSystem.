<?php
include "db.php";
echo "✅ Database Connected Successfully";
?>
