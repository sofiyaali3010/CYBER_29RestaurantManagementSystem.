<?php
ob_start();
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "restaurant_DB";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

