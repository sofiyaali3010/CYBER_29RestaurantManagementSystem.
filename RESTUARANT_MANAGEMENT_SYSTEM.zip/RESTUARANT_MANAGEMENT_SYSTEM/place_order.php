<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'customer') {
    header("Location: login.php");
    exit;
}

$menu = $conn->query("SELECT * FROM menu_items");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_name = $_SESSION['name'];
    $item_name = $_POST['item_name'];

    $sql = "INSERT INTO orders (customer_name, item_name, status) VALUES ('$customer_name', '$item_name', 'pending')";
    if ($conn->query($sql)) {
        echo "<script>alert('Order placed successfully!');</script>";
    } else {
        echo "<script>alert('Error placing order!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Place Order</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dashboard">
    <h2>Place Your Order 🍴</h2>
    <form method="POST">
      <select name="item_name" required>
        <option value="">-- Select Item --</option>
        <?php while ($row = $menu->fetch_assoc()) { ?>
          <option value="<?php echo $row['name']; ?>"><?php echo $row['name'] . " - ₹" . $row['price']; ?></option>
        <?php } ?>
      </select>
      <button type="submit">Place Order</button>
    </form>
    <a href="user_dashboard.php">⬅ Back to Dashboard</a>
  </div>
</body>
</html>
