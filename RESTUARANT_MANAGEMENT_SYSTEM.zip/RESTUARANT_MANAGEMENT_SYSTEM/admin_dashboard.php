<?php
ob_start();

session_start();
if(!isset($_SESSION['name']) || $_SESSION['user_type'] != 'admin'){
   header("Location: http://localhost/RESTUARANT_MANAGEMENT_SYSTEM/admin_dashboard.php");
exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>

<style>
body{
    font-family:Poppins;
    background:linear-gradient(to right,#ffe4ec,#e8faff);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}
.box{
    background:white;
    padding:30px;
    border-radius:20px;
    width:420px;
    text-align:center;
    box-shadow:0 8px 15px rgba(0,0,0,0.1);
}
button{
    width:100%;
    padding:12px;
    margin-top:10px;
    background:#ff96c2;
    color:white;
    border:none;
    border-radius:12px;
    font-weight:bold;
}
button:hover{ background:#ff5f9e; }
h2{ color:#ff6fa5; }
</style>
</head>

<body>

<div class="box">
<h2>Welcome Admin 🎀 <?php echo $_SESSION['name']; ?></h2>

<button onclick="location.href='add_menu.php'">Add Menu Item</button>
<button onclick="location.href='view_menu.php'">View Menu Items</button>
<button onclick="location.href='view_orders.php'">View All Orders</button>
<button onclick="location.href='logout.php'">Logout</button>
</div>

</body>
</html>
