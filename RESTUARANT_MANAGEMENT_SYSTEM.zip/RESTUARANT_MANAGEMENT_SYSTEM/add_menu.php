<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category = $_POST['category'];

    $sql = "INSERT INTO menu_items (name, price, category) VALUES ('$name', '$price', '$category')";
    if ($conn->query($sql)) {
        echo "<script>alert('Item added successfully!');</script>";
    } else {
        echo "<script>alert('Error adding item!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Menu Item</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dashboard">
    <h2>Add Menu Item 🍽️</h2>
    <form method="POST">
      <input type="text" name="name" placeholder="Item Name" required>
      <input type="number" step="0.01" name="price" placeholder="Price" required>
      <select name="category">
        <option value="veg">Veg</option>
        <option value="nonveg">Non-Veg</option>
      </select>
      <button type="submit">Add Item</button>
    </form>
    <a href="admin_dashboard.php">⬅ Back to Dashboard</a>
  </div>
</body>
</html>
