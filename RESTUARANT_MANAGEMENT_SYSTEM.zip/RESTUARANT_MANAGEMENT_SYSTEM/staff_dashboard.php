<?php
session_start();
if(!isset($_SESSION['user_type'])){
    header("Location: login.php");
    exit;
}
?>

<h2>Welcome User: <?php echo $_SESSION['user_name']; ?></h2>
<a href="logout.php">Logout</a>
