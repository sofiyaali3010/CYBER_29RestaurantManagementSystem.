<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header("Location: login.php");
    exit;
}

$orders = $conn->query("SELECT * FROM orders");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Orders</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dashboard">
    <h2>All Orders 📦</h2>
    <table border="1" align="center" cellpadding="10">
      <tr style="background-color:#ffb6c1;">
        <th>Order ID</th>
        <th>Customer Name</th>
        <th>Item</th>
        <th>Status</th>
      </tr>
      <?php while ($row = $orders->fetch_assoc()) { ?>
      <tr style="background-color:#fff0f5;">
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['customer_name']; ?></td>
        <td><?php echo $row['item_name']; ?></td>
        <td><?php echo ucfirst($row['status']); ?></td>
      </tr>
      <?php } ?>
    </table>
    <br>
    <a href="admin_dashboard.php">⬅ Back to Dashboard</a>
  </div>
</body>
</html>
