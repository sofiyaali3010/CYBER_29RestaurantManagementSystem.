<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<title>User Login</title>

<style>
body{
    margin:0;
    padding:0;
    font-family:Poppins, sans-serif;
    background:linear-gradient(to right,#ffe4ec,#e8faff);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.login-box{
    background:white;
    padding:30px;
    width:330px;
    border-radius:20px;
    text-align:center;
    box-shadow:0 8px 15px rgba(0,0,0,0.1);
}

input{
    width:100%;
    padding:12px;
    margin-bottom:12px;
    border:1px solid #ffd5e5;
    border-radius:10px;
    background:#fff8fc;
}

button{
    width:100%;
    padding:12px;
    background:#ff96c2;
    color:white;
    font-weight:bold;
    border:none;
    border-radius:12px;
}

button:hover{ background:#ff5f9e; }
</style>

</head>
<body>

<div class="login-box">
    <h2 style="color:#ff6fa5;">Login 🍰</h2>

    <form method="POST" action="login_check.php">
        <input type="email" name="email" required>
        <input type="password" name="password" required>

        <button type="submit">Login</button>
    </form>
</div>

</body>
</html>
