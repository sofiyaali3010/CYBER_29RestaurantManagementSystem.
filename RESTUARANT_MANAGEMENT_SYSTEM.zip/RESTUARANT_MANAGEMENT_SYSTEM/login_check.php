<?php
ob_start();
session_start();
include "db.php";

$email = trim($_POST['email']);
$password = trim($_POST['password']);

$sql = "SELECT * FROM user WHERE Email='$email' AND Password='$password' LIMIT 1";
$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0){
    $row = mysqli_fetch_assoc($result);

    $_SESSION['user_name'] = $row['name'];
    $_SESSION['user_type'] = $row['User_Type'];

    if($row['User_Type'] === 'admin'){
        header("Location: admin_dashboard.php");
        exit;
    } else {
        header("Location: user_dashboard.php");
        exit;
    }
}
else {
    echo "<script>alert('Wrong Login Info'); window.location='login.php';</script>";
}
?>
