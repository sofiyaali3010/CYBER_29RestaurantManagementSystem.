<?php
include 'db.php';
session_start();

$result = $conn->query("SELECT * FROM menu_items");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Menu</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dashboard">
    <h2>Our Menu 🌸</h2>
    <table border="1" align="center" cellpadding="10">
      <tr style="background-color:#ffb6c1;">
        <th>ID</th>
        <th>Name</th>
        <th>Price (₹)</th>
        <th>Category</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()) { ?>
      <tr style="background-color:#fff0f5;">
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['price']; ?></td>
        <td><?php echo ucfirst($row['category']); ?></td>
      </tr>
      <?php } ?>
    </table>
    <br>
    <a href="<?php echo ($_SESSION['user_type'] == 'admin') ? 'admin_dashboard.php' : 'user_dashboard.php'; ?>">⬅ Back</a>
  </div>
</body>
</html>
